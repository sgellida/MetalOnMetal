import plugintools
from logos import logos_bands

OFFICIAL_GREATEST_HITS = "plugin://plugin.video.youtube/playlist/PLQlc99hV-nkGWDaG-gJxwOfqp8jxyHaaQ/"
BACK_IN_BLACK = "plugin://plugin.video.youtube/playlist/PLx1MDbsLNfVQixI3AkXu862cZHi5XMev1/"
RIVER_PLATE = "plugin://plugin.video.youtube/playlist/PLx1MDbsLNfVTiAIYbfgqg_8mCPAjvBxeV/"

def acdc1(params):
    logo=logos_bands.acdc(params)
    
    plugintools.add_item( 
        title="Official Greatest Hits",
        url=OFFICIAL_GREATEST_HITS,
        thumbnail=logo, folder=True )  
                         
    plugintools.add_item( 
        title="Back in Black Videos",
        url=BACK_IN_BLACK,
        thumbnail=logo, folder=True )   

    plugintools.add_item( 
        title="Live River Plate 2009",
        url=RIVER_PLATE,
        thumbnail=logo, folder=True ) 



