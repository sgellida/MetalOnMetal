import plugintools
from logos import logos_bands

OFFICIAL_VIDEOS = "plugin://plugin.video.youtube/playlist/PLBCkm4VYo_DgzDg5O2-8UxgzZ6iVC_iza/"

def amorphis1(params):
    logo=logos_bands.amorphis(params)

    plugintools.add_item( 
        title="Official Videos",
        url=OFFICIAL_VIDEOS,
        thumbnail=logo, folder=True )  
