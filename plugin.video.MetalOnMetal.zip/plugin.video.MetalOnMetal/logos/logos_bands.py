def accept(params):
	return "https://lh3.googleusercontent.com/pw/ACtC-3drTXXLxUxGqP1Auzo9WyYNPaU2FH-XFNJJU5EEAJu88marsVoG2LAjb33Xw6JhJT5RelL_6dH-NvVeHZHdlZtmgrTRoC2msb_om7oLGLUL_L_0mNuZa9g1zIWzLz8_7ABNnnwKXDx-WVk-c9nS9nI"
    
def acdc(params):
	return "https://lh3.googleusercontent.com/pw/ACtC-3c90k5PBtgDR-XHp5d8KLMy_aYMy-nQXwbRfsttbs_KOe247OT-xkVvWnELAjeC0mbWTsnu3q56h_OxjQj6UzEqmRz_aZa2jtCjbJCn42MGd9vJmEHf9Ql5h5xSB4Bo5GtLBx7Aqhe3S7GXCU2FkMAn=w1132-h699-no?authuser=0"
	
def amorphis(params):
	return "https://lh3.googleusercontent.com/pw/ACtC-3cdh95ZXFa-qrB3iRb0uQyKyzDwqVJXfcIu7lzP8SP2mNzw_Qtc2TokTHFpbgqMD-iel7A5I-UriPCgAhgRvo6VTwgvpB_90MAopqiCohzxtZwqexcPIV_rf4xlfU_cjNOl4QqLVo3bvBAu0FYW7jTL=w960-h716-no?authuser=0"
	
def anthrax(params):
	return "https://lh3.googleusercontent.com/pw/ACtC-3fA8J9KMQCAwHEUR_EauTRaDALC3fs7gacvSlj3VElPEfx-pGZTmx-0rRiTZmP6e54WY7UDzXco6SHWe9tt_NI0WRCwmL1Rnt-l7pqgbF1Hw0TtGaJrfdCfJVM6CxSa_1FCPkpGIfW1H_Ho2tpV1v8=w1267-h950-no"
