def wacken(params):
    return "https://lh3.googleusercontent.com/pw/ACtC-3ehTEHAljw5jhTpNIJwcjF_tqEo7axR5sDQ6j0bDOUYAi1QCCP5dA1rjx9QohVhmLfkt-Hcop447RvH8zvUGCvESa6ZZ2T6hMALYkrvEx7Xy7A0p6WpZ2lOMWLP0yQoGAOa9AIQ77fbGxRTz0m_UeE=w1200-h800-no"
   
def hellfest(params):    
    return "https://lh3.googleusercontent.com/pw/ACtC-3c4lz60GGELnzyZ_kPFs548d6X_vlMspbpLn5liLWoGwT8U_pQDVvYO2RoHqOsbV0hLKYXT4_oO9ehmrWaLXEYWbuQJxbJA0ZVggIefLLbC-VppPa98ypOgRm9w8u8cvii7sdQpIvCDw4EgYzRxCzk=w1344-h950-no?authuser=0"
