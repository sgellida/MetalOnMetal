# -*- coding: utf-8 -*-
#------------------------------------------------------------
# Sourced From Online Templates And Guides
#------------------------------------------------------------
# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)
# Based on code from youtube addon
#
# Thanks To: Google Search For This Template
# Modified: Pulse
#------------------------------------------------------------

import os
import sys
import plugintools
import xbmc,xbmcaddon
from addon.common.addon import Addon
addonID = 'plugin.video.MetalOnMetal'
addon = Addon(addonID, sys.argv)
local = xbmcaddon.Addon(id=addonID)

xbmc.executebuiltin('Container.SetViewMode(500)')

AMUSIA = "https://lh3.googleusercontent.com/pw/ACtC-3d6tm_EpE86g-C3ARH2rZSVVOZzJ-i5LzAISCWdHL3XilSaaxlPT6sP8YEbrTE_ZsjTW2E1wJ9oPKCJWO9NLFuvNWT-UDq7voQvcWRwLXgjTPguWC4gA_MKwjvN21GZaOVUebR0nSYoHgesDt0m8HM=w575-h286-no?authuser=0"

SHAUN_TRACK = "https://lh3.googleusercontent.com/pw/ACtC-3dlL4fkjGDoCZpC1fcR3I9PocYp1z40XfQPV1cGK05NJRAKOqpNDHRDfRBwoAbKlg2O7quqDiFNRCEl4M7-KaOK9zWcCdk0D8UK1X6aIRYrWB0BpjrlsX3XL_6CARMScSJMeajjRR02Lf9BYX0EGlw=w1280-h720-no"

YOUTUBE_CHANNEL_SHAUN_TRACK_METAL = "PLgyUYejNPEs2N30vrCZHF6sgae6teIUjs"
YOUTUBE_CHANNEL_SHAUN_TRACK_ROCK = "PLgyUYejNPEs2pL_5qiAEe1V5hIw7rlUjy"
YOUTUBE_CHANNEL_30_YEARS_OF_NUCLEAR_BLAST = "PLB4brr7vf-P4Sw27U1AsJvIevX5D7TQeW"

### BANDS
def f_accept(params):
    from bands import accept
    accept.accept1(params)

def f_acdc(params):   
    from bands import acdc
    acdc.acdc1(params)          

def f_amorphis(params):
    from bands import amorphis
    amorphis.amorphis1(params)          
      
def f_anthrax(params):
    from bands import anthrax
    anthrax.anthrax1(params)      
        
### FESTIVALS

def f_wacken(params):
    from festivals import wacken
    wacken.wacken1(params) 

def f_hellfest(params):
    from festivals import hellfest
    hellfest.hellfest1(params) 
  
   
 ###########################################################
 ################ BANDS ####################################
 ###########################################################
          
def bands(params):
    from logos import logos_bands
    ACCEPT=logos_bands.accept(params)
    ACDC=logos_bands.acdc(params)
    AMORPHIS=logos_bands.amorphis(params)
    ANTHRAX=logos_bands.anthrax(params)
    plugintools.add_item(action="f_accept",title="Accept", thumbnail=ACCEPT, folder=True )  
    plugintools.add_item(action="f_acdc", title="AC/DC", thumbnail=ACDC, folder=True )  
    plugintools.add_item(action="f_amorphis", title="Amorphis", thumbnail=AMORPHIS, folder=True )  
    plugintools.add_item(action="f_anthrax", title="Anthrax", thumbnail=ANTHRAX, folder=True )       

 ###########################################################
 ################ FESTIVALS ################################
 ###########################################################
 
def festivals(params):
    from logos import logos_festivals
    WACKEN=logos_festivals.wacken(params)
    HELLFEST=logos_festivals.hellfest(params)
    plugintools.add_item(action="f_wacken",title="Wacken", thumbnail=WACKEN, folder=True )  
    plugintools.add_item(action="f_hellfest",title="Hellfest", thumbnail=HELLFEST, folder=True )  

def run():
    plugintools.log("docu.run")
    
    # Get params
    params = plugintools.get_params()
    
    if params.get("action") is None:
        main_list(params)
    else:
        action = params.get("action")
        exec action+"(params)"
    
    plugintools.close_item_list()

# Main menu
def main_list(params):
    plugintools.log("docu.main_list "+repr(params))
    
    plugintools.add_item( 
        action="bands", 
        title="Bands",
        #url="",
        thumbnail="https://lh3.googleusercontent.com/pw/ACtC-3eElb6lCwWPG9t29fTLR-N3A8ZJf2Lm_xQFdbvdqCs9OFofxWNQl68R_gMbIBZay1KgAELYMAa67908BrosdQSR1SXchSJTXCByakz6yhQjjnVeeJVeDZyKlGX-ETCN2qv_9pU39bQIwcJwXIdm1NZM=w1260-h934-no",
        folder=True )  
          
    plugintools.add_item( 
        action="festivals", 
        title="Festivals",
        thumbnail="https://lh3.googleusercontent.com/pw/ACtC-3ehTEHAljw5jhTpNIJwcjF_tqEo7axR5sDQ6j0bDOUYAi1QCCP5dA1rjx9QohVhmLfkt-Hcop447RvH8zvUGCvESa6ZZ2T6hMALYkrvEx7Xy7A0p6WpZ2lOMWLP0yQoGAOa9AIQ77fbGxRTz0m_UeE=w1200-h800-no",
        folder=True ) 



####### Añadir: Youtubers, discograficas, documentales, listas especiales, 
run()
